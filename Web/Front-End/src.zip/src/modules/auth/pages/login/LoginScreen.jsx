import AuthLayout from '../../components/AuthLayout/AuthLayout'
import AuthSlider from '../../components/AuthSlider/AuthSlider'

function LoginScreen() {
  return (
    <AuthLayout>
      <AuthSlider />
    </AuthLayout>
  )
}

export default LoginScreen
