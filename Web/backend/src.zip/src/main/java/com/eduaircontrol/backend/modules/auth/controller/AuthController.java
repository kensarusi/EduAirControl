package com.eduaircontrol.backend.modules.auth.controller;

import com.eduaircontrol.backend.modules.auth.dto.request.LoginRequest;
import com.eduaircontrol.backend.modules.auth.dto.request.RegisterRequest;
import com.eduaircontrol.backend.modules.auth.dto.response.AuthResponse;
import com.eduaircontrol.backend.modules.auth.entity.Users;
import com.eduaircontrol.backend.modules.auth.service.implement.UserService;
import com.eduaircontrol.backend.modules.security.JwtService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
public class AuthController {
    private final UserService userService;
    private final JwtService jwtService;
    
    //Registro
    @PostMapping("/register")
    public AuthResponse register(@Valid @RequestBody RegisterRequest request){
        Users user = userService.register(request);
        String token = jwtService.generateToken(user);
        
        return new AuthResponse(token);
    }
    
    @PostMapping("/login")
    public AuthResponse login(@Valid @RequestBody LoginRequest request){
        
        String token = userService.login(request);
        
        return new AuthResponse(token);
    }

}
